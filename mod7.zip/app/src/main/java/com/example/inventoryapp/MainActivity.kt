import android.R
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var usernameEditText: EditText? = null
    private var passwordEditText: EditText? = null
    private var loginButton: Button? = null
    private var registerButton: Button? = null
    private var dbHelper: DatabaseHelper? = null

    protected fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)
        usernameEditText = findViewById(R.id.username)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.login_button)
        registerButton = findViewById(R.id.register_button)

        loginButton!!.setOnClickListener {
            val username = usernameEditText!!.text.toString()
            val password = passwordEditText!!.text.toString()
            if (dbHelper.checkUser(username, password)) {
                Toast.makeText(
                    this@MainActivity,
                    "Login successful",
                    Toast.LENGTH_SHORT
                ).show()
                // Transition to main app screen here
            } else {
                Toast.makeText(this@MainActivity, "Login failed", Toast.LENGTH_SHORT)
                    .show()
            }
        }

        registerButton!!.setOnClickListener {
            val username = usernameEditText!!.text.toString()
            val password = passwordEditText!!.text.toString()
            if (dbHelper.registerUser(username, password)) {
                Toast.makeText(
                    this@MainActivity,
                    "Registration successful",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this@MainActivity,
                    "Registration failed",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}